
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'AdminPage',
  templateUrl: './AdminPage.component.html',
  styleUrls: ['./AdminPage.component.scss']
})
export class AdminPageComponent implements OnInit {


constructor() {
  
}
  ngOnInit() {

  }


}
