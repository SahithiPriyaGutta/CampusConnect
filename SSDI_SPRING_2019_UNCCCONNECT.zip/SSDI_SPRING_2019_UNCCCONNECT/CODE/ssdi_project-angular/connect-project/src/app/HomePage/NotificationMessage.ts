export class NotificationMessage {

  attachment: string;

  message: string;

  fromStudentId: number;

  toStudentId: number;

}
