

export class PostDetails {
  private firstName: string;

  private middleName: string;

  private lastName: string;

  private category: string;

  private attachment: string;

  private postText: string;

 postId: number;

}
