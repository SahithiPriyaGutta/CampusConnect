-- MySQL dump 10.13  Distrib 5.7.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ssdi_project
-- ------------------------------------------------------
-- Server version	5.7.25-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_student_id` int(15) NOT NULL,
  `to_student_id` int(1) NOT NULL,
  `message` varchar(100) NOT NULL,
  `attachment` varchar(200) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `send_time` datetime NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,801010110,801101049,'Hii','https://s3.ap-south-1.amazonaws.com/ssdibucket0/Dasaradhi Jetti Resume.docx',1,'2019-04-18 22:51:35'),(2,801101049,801010110,'null',NULL,1,'2019-04-22 22:28:13'),(3,801101049,801010110,'null',NULL,1,'2019-04-22 22:28:16'),(4,801101049,801010110,'Hii',NULL,1,'2019-04-23 16:56:16'),(5,801010110,801101049,'Send',NULL,1,'2019-04-23 20:14:25');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `category` varchar(20) DEFAULT NULL,
  `attachment` varchar(200) DEFAULT NULL,
  `post_text` varchar(50) NOT NULL,
  `updated_date` datetime NOT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`post_id`),
  KEY `student_id` (`student_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,801101049,'Academic',NULL,'Systems development efforts are gradually \n\n','2019-04-18 22:18:54',0),(2,801101049,'Food','https://s3.ap-south-1.amazonaws.com/ssdibucket0/801101049/Food/2.jpeg','','2019-04-18 22:20:39',0),(3,801101049,'Discount','https://s3.ap-south-1.amazonaws.com/ssdibucket0/801101049/Discount/2.jpeg','DISCOUNT sale!!!!\n.....ZARA....','2019-04-18 22:22:42',1),(4,801101049,'',NULL,'','2019-04-18 22:35:43',1),(5,801101049,'',NULL,'','2019-04-18 22:35:53',1),(6,801101049,'',NULL,'','2019-04-18 22:36:12',1),(7,801101049,'',NULL,'','2019-04-18 22:36:13',1),(8,801101049,'Food',NULL,'Free FOOD- Sovi','2019-04-18 22:41:13',0),(9,801010110,'Job Opportunities',NULL,'Please share resumes to xxx@ymail.com','2019-04-23 16:45:20',0),(10,801010110,'Entertainment',NULL,'Music Concert at Student Union. Hurry Up!!!','2019-04-23 17:03:45',0),(11,801010110,'Job Opportunities',NULL,'Amazon invites you','2019-04-23 19:03:04',0),(12,801010110,'Job Opportunities',NULL,'UNCC invites you to join','2019-04-23 19:21:18',0),(13,801010110,'Entertainment','https://s3.ap-south-1.amazonaws.com/ssdibucket0/801010110/Entertainment/he.jpg','Marvel-Endgame','2019-04-23 19:42:44',1),(14,801010110,'Academic',NULL,'SSDI Presentations..','2019-04-23 19:44:08',0);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `student_id` int(15) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `personal_email_id` varchar(255) NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `linked_in_id` varchar(100) NOT NULL,
  `graduation_year` int(50) NOT NULL,
  `major` varchar(100) NOT NULL,
  `student_type` varchar(255) NOT NULL,
  `profile_pic` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (801010110,'Uma Sai','Bhavani','Jetty','chinnu.jetti@gmail.com','8134205414','12345678','umajetti.linkedin',2019,'CS','Student','https://s3.ap-south-1.amazonaws.com/ssdibucket0/801010110/profilePic/he.jpg'),(801101049,'Uma Sai Madhuri','','Jetty','madhu.jetty93@gmail.com','8134205414','Pinky2425','madhujetty93.linkenin',2020,'CS','Student','https://s3.ap-south-1.amazonaws.com/ssdibucket0/801101049/profilePic/me.jpeg');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ssdi_project'
--

--
-- Dumping routines for database 'ssdi_project'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-23 21:48:59
